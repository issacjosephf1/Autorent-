package com.autorent.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.content.Context

data class Driver(val name:String,val vehicle:String,val rent:Int)

class MainActivity : android.app.Activity() {
    private val drivers = listOf(Driver("Abhijit","5975",667),
Driver("Anoob","5968",655),
Driver("Sebastian","5958",640),
Driver("Sanjay","8479",651),
Driver("Haris","6884",586),
Driver("Shihabudheen","6943",600),
Driver("Joshy","6921",500),
Driver("Vishak","9155",660),
Driver("Shemeer","9584",840),
Driver("Jeevanlal","6880",601),
Driver("Rijas","2437",661),
Driver("Shihabudheen 2","4028",560),
Driver("Gopakumar","7844",665),
Driver("Govindraj","7983",561),
Driver("Unni","9258",890),
Driver("Jaffar","9213",611),
Driver("Pareed","9468",789),
Driver("Gokul","9402",750),
Driver("Shafeek","0131",669),
Driver("Nithin","0327",668),
Driver("Suraj","9266",562),
Driver("Salim","2587",685),
Driver("Rethish","9453",620),
Driver("Antony","9138",530),
Driver("Sheheer","1788",609),
Driver("Sindesh","2242",691),
Driver("Benson","4377",755),
Driver("Sainul","0386",612),
Driver("Noufal","9261",570),
Driver("Murali","5771",613),
Driver("Ansal","0337",580),
Driver("Arun","9227",670),
Driver("Unni P","0191",535),
Driver("Dhaneesh","7502",681),
Driver("Joseph","1272",625),
Driver("Viswanathan","4703",686),
Driver("Ajmal","9457",690))
    private val bg = Color.rgb(246,247,250)
    private val ink = Color.rgb(17,24,39)
    private val green = Color.rgb(220,245,228)
    private val yellow = Color.rgb(255,241,199)
    private val red = Color.rgb(255,224,224)
    private val blue = Color.rgb(220,236,255)
    private val purple = Color.rgb(234,223,255)
    private lateinit var content: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showDashboard()
    }

    private fun base(title:String): LinearLayout {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg)
        val head=LinearLayout(this); head.setPadding(20,18,20,18); head.setBackgroundColor(ink)
        val tv=TextView(this); tv.text=title; tv.textSize=24f; tv.setTextColor(Color.WHITE); tv.setTypeface(null,1)
        head.addView(tv, LinearLayout.LayoutParams(0,70,1f))
        root.addView(head)
        val nav=LinearLayout(this); nav.setPadding(8,8,8,8); nav.setBackgroundColor(Color.WHITE)
        listOf("Dashboard","Payments","Calendar","Drivers","Reports").forEach { label ->
            val x=Button(this); x.text=label; x.textSize=11f; x.setOnClickListener {
                when(label) {
                    "Dashboard"->showDashboard(); "Payments"->showPayments(); "Calendar"->showCalendar()
                    "Drivers"->showDrivers(); "Reports"->showReports()
                }
            }
            nav.addView(x,LinearLayout.LayoutParams(0,58,1f))
        }
        root.addView(nav)
        content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL; content.setPadding(16,16,16,24)
        val scroll=ScrollView(this); scroll.addView(content); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        return root
    }

    private fun text(s:String,size:Float=16f,bold:Boolean=false):TextView {
        val t=TextView(this); t.text=s; t.textSize=size; t.setTextColor(ink); t.setPadding(4,6,4,6)
        if(bold)t.setTypeface(null,1); return t
    }
    private fun card(title:String,value:String):LinearLayout {
        val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(16,14,16,14); l.setBackgroundColor(Color.WHITE)
        l.addView(text(title,12f,true)); l.addView(text(value,24f,true))
        val p=LinearLayout.LayoutParams(0,120,1f); p.setMargins(5,5,5,5); l.layoutParams=p; return l
    }
    private fun showDashboard() {
        val root=base("AutoRent")
        content.addView(text("Rent collection at a glance",14f))
        val row=LinearLayout(this)
        row.addView(card("VEHICLES","37")); row.addView(card("DAILY TARGET","₹23,938"))
        content.addView(row)
        val row2=LinearLayout(this)
        row2.addView(card("AUTO MATCH","2")); row2.addView(card("REVIEW","2"))
        content.addView(row2)
        val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(16,16,16,16); c.setBackgroundColor(Color.WHITE)
        c.addView(text("Today's workflow",18f,true))
        c.addView(text("UPI remark → vehicle number → driver → oldest outstanding rent",14f))
        c.addView(text("Recommended remark: 5975 or Auto 5975",14f,true))
        content.addView(c)
        setContentView(root)
    }
    private fun showPayments() {
        val root=base("Payment Inbox")
        content.addView(text("Demo incoming UPI transactions",14f))
        listOf(
            "₹667  •  Remark: 5975  •  Abhijit  •  AUTO-APPLIED",
            "₹500  •  Remark: 5975  •  Abhijit  •  PARTIAL — ₹167 BALANCE",
            "₹800  •  Remark: rent  •  NO VEHICLE — NEEDS REVIEW",
            "₹690  •  Remark: 9457  •  Ajmal  •  NEEDS REVIEW / DUPLICATE CHECK"
        ).forEach { s ->
            val c=LinearLayout(this); c.orientation=LinearLayout.VERTICAL; c.setPadding(14,12,14,12); c.setBackgroundColor(Color.WHITE)
            c.addView(text(s,15f,true)); content.addView(c)
            val sp=Space(this); content.addView(sp,LinearLayout.LayoutParams(1,8))
        }
        val amount=EditText(this); amount.hint="Test amount"; amount.setText("667"); content.addView(amount)
        val remark=EditText(this); remark.hint="UPI remark / vehicle number"; remark.setText("5975"); content.addView(remark)
        val btn=Button(this); btn.text="SIMULATE PAYMENT"; btn.setOnClickListener {
            Toast.makeText(this,"Payment detected. Matching vehicle "+remark.text+" and allocating oldest outstanding rent.",Toast.LENGTH_LONG).show()
        }; content.addView(btn)
        setContentView(root)
    }
    private fun showCalendar() {
        val root=base("Driver Calendar")
        val s=Spinner(this); s.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,drivers.map{"${it.name} — ${it.vehicle} — ₹${it.rent}"}); content.addView(s)
        content.addView(text("September 2026",20f,true))
        val grid=GridLayout(this); grid.columnCount=7
        listOf("SUN","MON","TUE","WED","THU","FRI","SAT").forEach{ grid.addView(text(it,11f,true)) }
        for(d in 1..30) {
            val v=text(d.toString()+"\nPAID",13f,true); v.gravity=Gravity.CENTER; v.setBackgroundColor(green)
            if(d==4||d==11||d==18||d==25) { v.text=d.toString()+"\nWEEKLY OFF"; v.setBackgroundColor(blue) }
            if(d==7||d==21) { v.text=d.toString()+"\nPARTIAL"; v.setBackgroundColor(yellow) }
            if(d==9||d==23) { v.text=d.toString()+"\nDUE"; v.setBackgroundColor(red) }
            if(d==14) { v.text=d.toString()+"\nCARRIED OFF"; v.setBackgroundColor(purple) }
            val p=GridLayout.LayoutParams(); p.width=0; p.height=92; p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); p.setMargins(3,3,3,3); grid.addView(v,p)
        }
        content.addView(grid)
        content.addView(text("PAID = full rent • PARTIAL = balance remains • DUE = outstanding • WEEKLY OFF = no rent • CARRIED OFF = unused weekly off used later",13f))
        setContentView(root)
    }
    private fun showDrivers() {
        val root=base("Drivers & Vehicles")
        content.addView(text("37 active vehicles",14f))
        drivers.forEach { d ->
            val r=LinearLayout(this); r.orientation=LinearLayout.HORIZONTAL; r.setPadding(10,8,10,8); r.setBackgroundColor(Color.WHITE)
            r.addView(text(d.name,14f,true),LinearLayout.LayoutParams(0,70,1f))
            r.addView(text(d.vehicle,14f,true),LinearLayout.LayoutParams(0,70,1f))
            r.addView(text("₹"+d.rent,14f,true),LinearLayout.LayoutParams(0,70,1f))
            content.addView(r)
        }
        setContentView(root)
    }
    private fun showReports() {
        val root=base("Reports")
        content.addView(text("Fleet collection report",20f,true))
        content.addView(text("37 vehicles • ₹23,938 expected per full collection day",15f))
        content.addView(text("Allocation rule: oldest outstanding rent first",15f,true))
        content.addView(text("Exception queue: unknown vehicle, duplicate transaction, ambiguous remark",14f))
        setContentView(root)
    }
}
