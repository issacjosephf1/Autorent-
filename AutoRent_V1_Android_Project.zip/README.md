# AutoRent V1 Android Project

This is the first native Android project for the AutoRent rent-management app.

Included:
- 37 real driver/vehicle/rent records
- Dashboard
- Payment Inbox demo
- Driver calendar with high-contrast status cells
- Drivers/Vehicles list
- Reports
- UPI remark matching demonstration
- Daily expected rent: ₹23,938

Important:
This is a V1 project scaffold for compilation in Android Studio. It does NOT yet access bank SMS or UPI notifications. That should be added only after the ledger and permission/privacy design are finalized.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated debug APK on an Android phone.

